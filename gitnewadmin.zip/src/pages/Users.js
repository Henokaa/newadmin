import React, { useState } from 'react'
import ContactList from '../components/ContactList';
function Users() {
    
    return (
        <div><ContactList /></div>
     );
}

export default Users;