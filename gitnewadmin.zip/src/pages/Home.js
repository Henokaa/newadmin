import React, { Component, useState, useEffect } from "react";
import Chart from "react-apexcharts";
import ReactApexChart from "react-apexcharts";
import BarChart from "../components/BarChart";

import { Grid, Container, Typography } from '@material-ui/core';
import AppWidgetSummary from "../components/AppWidgetSummary";
import { Box } from '@material-ui/core';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import {Bar} from "react-chartjs-2";
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
);
function Home() {
    const [chartData, setChartData] = useState({
      datasets: [],
    });

    const [chartOptions, setChartOptions] = useState({});

    useEffect(() => {
      setChartData({
        labels: ["March", "April", "June", "July", "Augest"],
        datasets: [
          {
            label: "This year revenue",
            data: [12, 55, 34, 120, 720],
            borderColor: "rgb(53, 162, 235)",
            backgroundColor: "rgba(53, 162, 235, 0.4)",
          },
        ],
      });
      setChartOptions({
        responsive: true,
        plugins: {
          legend: {
            position: "top"
          },
          title: {
            display: true,
            text: "revenues"
          }
        }
      })
    }, [])
    return (
      <div>
      <Box title="Dashboard">
      <Container maxWidth="xl">
        <Typography variant="h4" sx={{ mb: 5 }}>
          Welcome Back, Lesan Admin
        </Typography>

        <Grid container spacing={3}>
          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary title="Weekly Sales" total={714000} />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary title="Monthly Sales" total={824000} />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary title="Yearly Sales" total={934000} />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <AppWidgetSummary title="Yearly Sales" total={434000} />
          </Grid>
          </Grid>
        </Container>
        </Box>
        
        <div id="chart">
        <Bar options={chartOptions} data= {chartData} />
        <BarChart/>
      </div>
      </div>
    );
  }

export default Home;